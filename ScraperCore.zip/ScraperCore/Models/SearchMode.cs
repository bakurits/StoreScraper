﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace ScraperCore.Models
{
    public enum SearchMode
    {   
        SearchAPI, 
        NewArrivalsPage
    }
}
